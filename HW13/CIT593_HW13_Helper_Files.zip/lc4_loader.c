#include <stdio.h>
#include "lc4_memory.h"

/* declarations of functions that must defined in lc4_loader.c */

FILE* get_file() 
{
	return NULL ;
}

int parse_file (FILE* my_obj_file, struct row_of_memory* memory) 
{
	return 0 ;
}
