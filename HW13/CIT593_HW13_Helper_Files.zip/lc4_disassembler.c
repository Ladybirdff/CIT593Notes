#include <stdio.h>
#include "lc4_memory.h"

int reverse_assemble (struct row_of_memory* memory) 
{

	return 0 ;
}
